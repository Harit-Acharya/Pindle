import json
import os.path
import sys
from PyQt5.QtGui import QIcon, QMovie
from PyQt5.QtWidgets import QErrorMessage, QMainWindow, QApplication, QPushButton, QFileSystemModel, QTreeView, \
    QListWidget, QListWidgetItem, QListView
from PyQt5 import uic, QtCore, QtWidgets


class UI(QMainWindow):
    def __init__(self):
        super(UI, self).__init__()
        uic.loadUi("/etc/Pindle/Categorizer/categorization2.ui", self)
        self.setWindowTitle("Pindle Categorizer")
        self.setGeometry(0, 0, self.frameSize().width(), self.frameSize().height())
        self.centerOnScreen()
        self.setFixedSize(1010,860)
        self.setWindowIcon(QIcon("/usr/share/pixmaps/Pindle/Categorizer/candy.png"))
        self.error_dialog = QErrorMessage()
        self.loadpaths()
        self.listview = self.findChild(QListWidget,"listWidget")
        self.listview.setMovement(QListView.Free)
        self.tree = self.findChild(QTreeView,"DirectoryView")
        self.remove = self.findChild(QPushButton,"pushButton_4")
        self.back=self.findChild(QPushButton,"pushButton")
        self.model = QFileSystemModel()
        self.model.setReadOnly(True)
        self.model.setRootPath('/')
        self.tree.setModel(self.model)
        self.tree.header().hideSection(1)
        self.tree.header().hideSection(2)
        self.tree.header().hideSection(3)
        self.paths_tolist()
        self.tree.clicked.connect(self.add_dir)
        self.pushButton_2.clicked.connect(self.trying)
        self.remove.clicked.connect(self.remove_dir)
        self.back.clicked.connect(self.trying2)

    def paths_tolist(self):
        for direc in self.paths:
            item = QListWidgetItem(direc)
            self.listview.addItem(item)

    def centerOnScreen(self):
        resolution = QtWidgets.QDesktopWidget().screenGeometry()
        self.move((resolution.width() // 2) - (self.frameSize().width() // 2),
                  (resolution.height() // 2) - (self.frameSize().height() // 2))

    def trying(self):
        self.label_2.setGeometry(QtCore.QRect(305, 340, 400, 180))
        self.label_2.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.movie = QMovie('/usr/share/pixmaps/Pindle/Categorizer/waited.gif')
        self.label_2.setMovie(self.movie)
        timer = QtCore.QTimer(self)
        self.movie.start()
        timer.singleShot(2000, self.stopanimate)

    def trying2(self):
        self.label_2.setGeometry(QtCore.QRect(305, 340, 400, 180))
        self.label_2.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.movie = QMovie('/usr/share/pixmaps/Pindle/Categorizer/waited.gif')
        self.label_2.setMovie(self.movie)
        timer = QtCore.QTimer(self)
        self.movie.start()
        timer.singleShot(2000, self.stopanimate2)

    def stopanimate2(self):
        import firstpage
        self.savepaths()
        self.window2 = firstpage.UI()
        self.window2.show()
        self.movie.stop()
        self.close()

    def add_dir(self,index):
        try:
            direc = self.model.filePath(index)
            add = 1
            if os.path.isdir(direc) and not(direc in self.paths) and (direc not in self.notallowed):
                for path in self.paths:
                    if os.path.dirname(direc) in self.paths:
                        add = 0
                        self.error_dialog.showMessage('Parent Directory is already in list!!')
                        break
                    if os.path.commonprefix([direc[1:],path[1:]]) != '':
                        if len(direc)<len(path):
        #                       remove from listview
                            self.paths.remove(path)
                            add = 1
                if add == 1:
                    item = QListWidgetItem(direc)
                    self.paths.append(direc)
                    self.listview.addItem(item)
            else:
                self.error_dialog.showMessage('Directory is already in list!!')
        except:
            pass

    def remove_dir(self):
        try:
            listItems = list(self.listview.selectedItems())
            if not listItems: return
            for item in listItems:
                index = self.listview.indexFromItem(item)
                self.listview.takeItem(index.row())
                self.paths.remove(item.text())
        except:
            pass

    def stopanimate(self):
        self.savepaths()
        self.movie.stop()
        os.system("systemctl restart categorize")
        exit(0)

    def savepaths(self):
        self.settings['paths'] = self.paths
        with open('/etc/Pindle/Categorizer/path_settings.json', 'w') as json_file:
            json.dump(self.settings, json_file)

    def loadpaths(self):
        with open('/etc/Pindle/Categorizer/path_settings.json','r') as f:
            self.settings = json.load(f)
        self.paths = self.settings['paths']
        self.notallowed = self.settings['dirs'].values()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = UI()
    window.show()
    a = app.exec_()
    sys.exit(a)


