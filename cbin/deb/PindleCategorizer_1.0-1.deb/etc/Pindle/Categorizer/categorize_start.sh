#!/bin/bash

python3 /etc/Pindle/Categorizer/dynamic_categorization.py &> /dev/null &
