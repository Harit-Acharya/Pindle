import json
import sys
from keyword import iskeyword
import sip
from PyQt5 import uic, QtCore, QtWidgets
from PyQt5.QtGui import QIcon,QMovie
from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QCheckBox, QComboBox, QErrorMessage
import secondpage

class UI(QMainWindow):
    def __init__(self):
        super(UI, self).__init__()
        uic.loadUi("/etc/Pindle/Categorizer/categorization.ui", self)
        self.setWindowTitle("Pindle Categorizer")
        self.setFixedSize(1010,860)
        self.setWindowIcon(QIcon("/usr/share/pixmaps/Pindle/Categorizer/candy.png"))
        self.categories, self.extensions = self.file_to_dict()
        self.verticallayoutlist = {"Documents":"verticalLayout",
                             "Pictures":"verticalLayout_2",
                             "Musics":"verticalLayout_3",
                             "Videos":"verticalLayout_4"}
        self.setGeometry(0, 0, self.frameSize().width(), self.frameSize().height())
        self.centerOnScreen()
        self.error_dialog = QErrorMessage()
        self.update_scrollview()
        self.Documents = self.findChild(QCheckBox,"Documents")
        self.Musics = self.findChild(QCheckBox, "Musics")
        self.Pictures = self.findChild(QCheckBox, "Pictures")
        self.Videos = self.findChild(QCheckBox, "Videos")
        self.type = self.findChild(QComboBox,"comboBox")
        self.secondpage = self.findChild(QPushButton,"pushButton_4")
        self.add = self.findChild(QPushButton, "pushButton_2")
        self.remove = self.findChild(QPushButton, "pushButton_3")
        self.secondpage.clicked.connect(self.trying)
        self.add.clicked.connect(self.additem)
        self.remove.clicked.connect(self.removeitem)

    def centerOnScreen(self):
        resolution = QtWidgets.QDesktopWidget().screenGeometry()
        self.move((resolution.width() // 2) - (self.frameSize().width() // 2),
                  (resolution.height() // 2) - (self.frameSize().height() // 2))

    def trying(self):
        self.label_8.setGeometry(QtCore.QRect(305, 200, 400, 180))
        self.label_8.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.movie = QMovie('/usr/share/pixmaps/Pindle/Categorizer/waited.gif')
        self.label_8.setMovie(self.movie)
        timer = QtCore.QTimer(self)
        self.movie.start()
        timer.singleShot(2000, self.stopanimate)

    def stopanimate(self):
        self.save_config()
        self.window = secondpage.UI()
        self.window.show()
        self.movie.stop()
        self.close()

    def additem(self):
        value = self.lineEdit.text()
        if value == '' or value == None: return
        try:
            if value[0] == '.': value = value[1:]
            if (not value in self.extensions[self.type.currentText()].keys()) and (not iskeyword(value)) and not value == '':
                value = self.lineEdit.text()
                setattr(self, value, QCheckBox(value))
                eval('self.'+value).setChecked(True)
                eval('self.'+value).setCheckable(True)
                eval('self.'+self.verticallayoutlist[self.type.currentText()]).addWidget(eval('self.'+value))
                self.setObjectName(value)
                self.extensions[self.type.currentText()][value] = 1
            else:
                self.error_dialog.showMessage('Extension is already in list or this is python keyword')
        except:
            pass
            
    def removeitem(self):
        value = self.lineEdit.text()
        if value == '' or value == None: return
        try:
            if value[0] == '.': value = value[1:]
            if (not value in self.extensions[self.type.currentText()].keys()) and not value == '':
                self.error_dialog.showMessage('Extension {} is not in list!!'.format(value))
            else:
                eval('self.' + self.verticallayoutlist[self.type.currentText()]).removeWidget(eval('self.' + value))
                sip.delete(eval('self.'+value))
                vars()[eval("self."+value)]=None
                del self.extensions[self.type.currentText()][value]
        except:
            pass

    def update_scrollview(self):
        for key,value in self.extensions.items():
            for name,state in value.items():
                setattr(self, name, QCheckBox(name))
                if state: eval('self.'+name).setChecked(True)
                else: eval('self.'+name).setChecked(False)
                eval('self.'+self.verticallayoutlist[key]).addWidget(eval('self.'+name))
                eval('self.' + name).setCheckable(True)
                self.setObjectName(name)

        for key,state in self.categories.items():
            if state: eval('self.' + key).setChecked(True)
            else: eval('self.' + key).setChecked(False)
            eval('self.' + key).setCheckable(True)

    def file_to_dict(self):
        with open('/etc/Pindle/Categorizer/category_settings.json') as f:
            categories = json.load(f)

        with open('/etc/Pindle/Categorizer/extension_settings.json') as f:
            extensions = json.load(f)

        return categories,extensions

    def save_config(self):
        for key,value in self.extensions.items():
            for name,state in value.items():
                check = eval('self.' + name).isChecked()
                if check == False:
                    self.extensions[key][name] = 0
                else:
                    self.extensions[key][name] = 1

        self.categories['Documents'] = int(self.Documents.isChecked())
        self.categories['Pictures'] = int(self.Pictures.isChecked())
        self.categories['Musics'] = int(self.Musics.isChecked())
        self.categories['Videos'] = int(self.Videos.isChecked())

        with open('/etc/Pindle/Categorizer/category_settings.json', 'w+') as json_file:
            json.dump(self.categories, json_file)

        with open('/etc/Pindle/Categorizer/extension_settings.json', 'w+') as json_file:
            json.dump(self.extensions, json_file)

if "__main__" == __name__:
    app = QApplication(sys.argv)
    window = UI()
    window.show()
    app.exec_()
