#!/bin/bash

python3 /etc/Pindle/Categorizer/update_categories.py &> /dev/null &
sudo systemctl start categorize_start
