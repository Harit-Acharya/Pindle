"""

After applying settings using GUI app
this script will make changes accordingly
Previous links or categories will be cleared
new settings will be applied

"""
import os
import json
import pathlib

def settings_fromfile():
    with open('/etc/Pindle/Categorizer/category_settings.json','r') as f:
        categories = json.load(f)

    with open('/etc/Pindle/Categorizer/extension_settings.json','r') as f:
        extensions = json.load(f)

    with open('/etc/Pindle/Categorizer/path_settings.json', 'r') as f:
        paths = json.load(f)

    return categories,extensions,paths['paths'],paths['dirs']

def apply():
    categories,extensions,paths,dirs = settings_fromfile()
    """
    we'll loop through list of paths selected by user 
    and categorize them as per categories and extensions
    """
    for dir in dirs.values():
        try:
            os.system('rm -f "{}"/*'.format(dir))
        except:
            pass

    for path in paths:
        for root,subdirectories,files in os.walk(path):
            for subdirectory in subdirectories:
                os.path.join(root,subdirectory)
            for file in files:
                for data_type in extensions:
                    ext = pathlib.Path(file).suffix[1:]
                    if (ext in extensions[data_type]) and (categories[data_type] == 1):
                        if extensions[data_type][ext] == 1:
                            try:
                                loc = os.path.join(root,file)
                                #print('sudo ln -sr {} {}/"{}"'.format(loc,dirs[data_type],str(loc.replace("/","-"))[1:]))
                                os.system('ln -s "{}" "{}"/"{}"'.format(loc,dirs[data_type],str(loc.replace("/","-"))[1:]))
                            except:
                                pass
    return "completed"

apply()
