import os
import json

with open("path_settings.json","r") as f:
    dest = json.load(f)

path = os.environ['desktop']

exts = ['Documents','Musics','Pictures','Videos']

for ext in exts:
    dest[ext] = os.path.join(path,ext)

with open('path_settings.json', 'w+') as json_file:
    json.dump(dest, json_file)

os.system("pyinstaller -F --hidden-import=win32timezone dynamic_categorization.py")
os.system("move dist\\dynamic_categorization.exe ..")
os.system("dynamic_categorization.exe install")
os.system("sc config Categorize start=auto")


os.system("pyinstaller -F --hidden-import=win32timezone update_categories.py")
os.system("move dist\\update_categories.exe ..")
os.system("update_categories.exe install")
os.system("sc config CategorizeNew start=auto")