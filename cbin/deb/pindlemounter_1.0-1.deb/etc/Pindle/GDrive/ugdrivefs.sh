#!/bin/bash

python3 /etc/Pindle/GDrive/umount_gdrive.py > /dev/null &
