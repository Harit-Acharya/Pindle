#!/bin/bash

python3 /etc/Pindle/GDrive/mount_gdrive.py &> /dev/null &
