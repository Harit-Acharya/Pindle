#!/usr/bin/bash

python3 /etc/Pindle/OneDrive/mount_onedrive.py > /dev/null &
