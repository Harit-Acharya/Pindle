#!/usr/bin/python3
import os
import time
import requests

globals()['connected'] = 1
url = "https://www.google.com"
timeout = 3
globals()['on'] = 0

def get_connection():
    try:
        request = requests.get(url, timeout=timeout)
        globals()['connected'] = 1
    except (requests.ConnectionError, requests.Timeout) as exception:
        globals()['connected'] = 0

get_connection()
if globals()['connected'] == 1:
    globals()['on'] = 1
    os.system("systemctl stop sync_offline")
    os.system("systemctl restart sync_remote")
else:
    globals()['on'] = 0
    os.system("systemctl stop sync_remote")
    os.system("systemctl restart sync_offline")

while(1):
    get_connection()
    if globals()['connected'] == 0:
        if globals()['on'] == 1:
            globals()['on'] = 0
            print("stopping remote")
            os.system("systemctl stop sync_remote")
            print("starting local")
            os.system("systemctl restart sync_offline")
        else:
            pass
    elif globals()['connected'] == 1:
        if globals()['on'] == 0:
            globals()['on'] = 1
            print("stopping local")
            os.system("systemctl stop sync_offline")
            print("starting remote")
            os.system("systemctl restart sync_remote")
        else:
            pass
    else:
        pass
    time.sleep(5)
