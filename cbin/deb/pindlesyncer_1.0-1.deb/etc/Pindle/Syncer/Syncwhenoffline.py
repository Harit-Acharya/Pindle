#!/usr/bin/python3
import json
from os.path import dirname

from watchdog.events import LoggingEventHandler
from watchdog.observers import Observer


class Changes():
    def __init__(self):
        self.mapped = {}
        self.connected = 0
        self.timeout = 3
        self.queue = []
        self.updates = {}
        self.paths = self.load_sessions()

    def load_sessions(self):
        try:
            with open('/etc/Pindle/Syncer/localname.json') as f:
                self.details = json.load(f)
            with open('/etc/Pindle/Syncer/pindleconfig.json', 'r') as f:
                self.changes = json.load(f)
            print(self.details['device2'])
        except:
            exit(0)

        self.instdir = self.details['insdir']
        self.mail = self.details['mailid']
        self.domain = self.mail[self.mail.index('@') + 1:]
        self.localname = self.details['localname']

        if self.changes['device1']['name'] == self.details['localname']:
            self.basedonkey = True
            self.tosave = self.changes['device2']['name']
            self.addwatch = self.changes["connections"].keys()
        else:
            self.basedonkey = False
            self.addwatch = self.changes["connections"].values()
            self.tosave = self.changes['device1']['name']
        return self.changes['connections']

    def save(self):
        self.sync = {}
        self.sync['updates'] = self.updates
        self.sync['queue'] = self.queue
        self.sync['mapped'] = self.mapped
        with open('/etc/Pindle/Syncer/{}_changes.json'.format(self.tosave), 'w+') as f:
            json.dump(self.sync, f)

def on_create(src):
    osrc = src.replace("/", "-")
    paths.mapped[osrc] = src
    if osrc in paths.queue:
        paths.queue.remove(osrc)
    paths.queue.append(osrc)
    if paths.basedonkey == True:
        location = paths.paths[dirname(src)]
    else:
        location = list(paths.paths.keys())[list(paths.paths.values()).index(dirname(src))]
    paths.updates[osrc] = (location, "created")
    print(paths.updates)
    print(paths.queue)
    print('uploading '+src)
    paths.save()

def on_deleted(src):
    osrc = src.replace("/", "-")
    paths.mapped[osrc] = src
    if osrc in paths.queue:
        paths.queue.remove(osrc)
    paths.queue.append(osrc)
    if paths.basedonkey == True:
        location = paths.paths[dirname(src)]
    else:
        location = list(paths.paths.keys())[list(paths.paths.values()).index(dirname(src))]
    paths.updates[osrc] = (location, "deleted")
    paths.save()

class Event(LoggingEventHandler):
    @staticmethod
    def on_any_event(event, **kwargs):
        if event.is_directory:
            # print(event)
            return None
        # Create a watchdog in Python to look for filesystem changes
        elif event.event_type == 'created' or event.event_type == "modified":
            try:
                print("created event")
                on_create(event.src_path)
            except:
                pass
        elif event.event_type == 'deleted':
            try:
                print("deleted")
                on_deleted(event.src_path)
            except:
                pass

if __name__ == "__main__":
    paths = Changes()
    event_handlers = Event()
    watcher = Observer()
    threads = []

    for i in paths.addwatch:
        targetPath = i
        print(i)
        watcher.schedule(event_handlers, targetPath, recursive=False)
        threads.append(watcher)

    try:
        watcher.start()
        # show network disconnected error
        watcher.join()
    except KeyboardInterrupt:
        watcher.stop()
