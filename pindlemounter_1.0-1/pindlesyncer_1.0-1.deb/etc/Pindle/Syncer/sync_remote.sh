#!/usr/bin

python3 /etc/Pindle/Syncer/Synctodestination.py > /dev/null &
python3 /etc/Pindle/Syncer/update_usage.py > /dev/null &