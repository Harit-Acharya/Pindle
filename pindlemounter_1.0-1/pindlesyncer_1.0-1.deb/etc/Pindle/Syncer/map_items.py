#!/usr/bin/python3
from collections import defaultdict
import time
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QErrorMessage,QMainWindow, QApplication,QPushButton,QFileSystemModel,QTreeView,QListWidget,QListWidgetItem,QLabel
from PyQt5 import uic
from PyQt5 import QtCore
from PyQt5.QtGui import QMovie
import sys
import os.path
import json
import onedrive,googledrive
import source_tree_items


class UI(QMainWindow):
    def __init__(self):
        super(UI, self).__init__()
        uic.loadUi("/etc/Pindle/Syncer/map_items.ui", self)
        self.setWindowTitle("Edit Configuration")
        self.setGeometry(0, 0, 840, 700)
        self.centerOnScreen()
        self.setWindowIcon(QIcon("/usr/share/pixmaps/Pindle/Syncer/sync.png"))
        self.error_dialog = QErrorMessage()
        self.load()
        self.pushButton.clicked.connect(self.back)
        self.pushButton_2.clicked.connect(self.next)
        self.comboBox.currentTextChanged.connect(self.dir1_name)
        self.comboBox_2.currentTextChanged.connect(self.dir2_name)
        self.pushButton_3.clicked.connect(self.add)
        self.pushButton_4.clicked.connect(self.remove)

    def dir1_name(self):
        self.label_6.setText(self.comboBox.currentText())

    def dir2_name(self):
        self.label_5.setText(self.comboBox_2.currentText())

    def load(self):
        try:
            with open('/etc/Pindle/Syncer/localname.json') as f:
                self.details = json.load(f)
        except:
            self.error_dialog.showMessage("localname.json file not found")
            time.sleep(10)
            exit(0)

        self.instdir = self.details['insdir']
        self.mail = self.details['mailid']
        self.domain = self.mail[self.mail.index('@') + 1:]
        if self.domain != "gmail.com":
            self.api = onedrive.LoadSession()
            onedrive.download(self.api, "pindleconfig.json", os.path.join(self.instdir,"pindleconfig.json"), 'file')
        else:
            self.api = googledrive.authenticate()
            googledrive.download(self.api, "pindleconfig.json", self.instdir, 'file')

        with open(os.path.join(self.instdir,'pindleconfig.json'),'r') as f:
            self.config = json.load(f)

        for item1,item2 in self.config['connections'].items():
            item = QListWidgetItem(item1)
            self.listWidget.addItem(item)
            item = QListWidgetItem(item2)
            self.listWidget_2.addItem(item)

        self.src_paths = self.config['device1']['connections']
        self.dst_paths = self.config['device2']['connections']
        self.mapped = self.config['connections']
        self.label.setText(self.config['device1']['name'])
        self.label_2.setText(self.config['device2']['name'])

        for item in self.src_paths:
            self.comboBox.addItem(item)
        self.label_6.setText(self.comboBox.currentText())

        for item in self.dst_paths:
            self.comboBox_2.addItem(item)
        self.label_5.setText(self.comboBox_2.currentText())

        if len(self.mapped.keys()) == 0:
            self.error_dialog.showMessage("Nothing to Sync!\nAdd some items")

    def centerOnScreen(self):
        resolution = QtWidgets.QDesktopWidget().screenGeometry()
        self.move((resolution.width() //2) - (self.frameSize().width() // 2),
                  (resolution.height() // 2) - (self.frameSize().height() // 2))

    def remove_items(self):
        all_items = []
        all_items2 = []
        for index in range(self.listWidget.count()):
            all_items.append(self.listWidget.item(index))
        for index in range(self.listWidget_2.count()):
            all_items2.append(self.listWidget_2.item(index))

        for item in all_items:
            if item.text() == self.label_6.text():
                self.listWidget.setCurrentItem(item)
                listItems = list(self.listWidget.selectedItems())
                for row in listItems:
                    index = self.listWidget.indexFromItem(row)
                    self.listWidget.takeItem(index.row())
                    self.listWidget_2.takeItem(index.row())
        for item in all_items2:
            if item.text() == self.label_5.text():
                self.listWidget_2.setCurrentItem(item)
                listItems = list(self.listWidget_2.selectedItems())
                for row in listItems:
                    index = self.listWidget_2.indexFromItem(row)
                    self.listWidget_2.takeItem(index.row())
                    self.listWidget.takeItem(index.row())

    def add(self):
        if self.label_6.text() == "" or self.label_5.text() == "":
            self.error_dialog.showMessage("One Item is missing!")
        else:
            self.remove_items()
            item = QListWidgetItem(self.label_6.text())
            self.listWidget.addItem(item)
            item = QListWidgetItem(self.label_5.text())
            self.listWidget_2.addItem(item)
            self.mapped[self.label_6.text()] = self.label_5.text()

    def remove(self):
        if (self.label_6.text(),self.label_5.text()) in self.mapped.items():
            self.remove_items()
            del self.mapped[self.label_6.text()]
        else:
            self.error_dialog.showMessage("No Such Pair exist!!")

    def back(self):
        self.label_7.setGeometry(QtCore.QRect(280, 250, 400, 180))
        self.label_7.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.label_7.setObjectName("label_7")
        self.movie1 = QMovie('/usr/share/pixmaps/Pindle/Syncer/waited.gif')
        self.label_7.setMovie(self.movie1)
        timer1 = QtCore.QTimer(self)
        self.movie1.start()
        timer1.singleShot(6000, self.stopanime)

    def stopanime(self):
        self.Apply()
        from source_tree_items import UI
        self.window = UI()
        self.window.show()
        self.close()

    def next(self):
        self.label_7.setGeometry(QtCore.QRect(280, 250, 400, 180))
        self.label_7.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.label_7.setObjectName("label_7")
        self.movie1 = QMovie('/usr/share/pixmaps/Pindle/Syncer/waited.gif')
        self.label_7.setMovie(self.movie1)
        timer1 = QtCore.QTimer(self)
        self.movie1.start()
        timer1.singleShot(6000, self.stopanimation)

    def stopanimation(self):
        self.Apply()
        from userstat2 import UI
        self.window = UI()
        self.window.show()
        self.close()

    def Apply(self):
        try:
            self.config['connections'] = self.mapped
            with open(os.path.join(self.instdir,'pindleconfig.json'), 'w+') as f:
                json.dump(self.config, f)
            if self.domain != "gmail.com":
                onedrive.upload(self.api, "Pindle", os.path.join(self.instdir,'pindleconfig.json'),'folder')
            else:
                googledrive.upload(self.api, os.path.join(self.instdir,'pindleconfig.json'), "Pindle", 'file')
            os.system("systemctl start sync_remote")
            self.error_dialog.showMessage("New Settings Applied Successfully")
        except:
            self.error_dialog.showMessage("Failed to apply new settings!")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = UI()
    window.show()
    app.exec_()

