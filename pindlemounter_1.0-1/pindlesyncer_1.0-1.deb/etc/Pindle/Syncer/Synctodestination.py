import time
import threading
from watchdog.observers import Observer
from watchdog.events import LoggingEventHandler
import logging
import json
import os
from os.path import basename,dirname
import onedrive
import googledrive
import requests

class Changes():
    def __init__(self):
        self.connected = 0
        self.url = "https://www.google.com"
        self.timeout = 3
        self.stack = []
        self.updates ={}
        self.paths = self.load_sessions()

    def get_connection(self):
        try:
            request = requests.get(self.url, timeout=self.timeout)
            self.connected = 1
        except (requests.ConnectionError, requests.Timeout) as exception:
            self.connected = 0

    def load_sessions(self):
        try:
            with open('localname.json') as f:
                self.details = json.load(f)
        except:
           #logger.debug("localname.json not found")
            time.sleep(10)
            exit(0)

        self.instdir = self.details['insdir']
        self.mail = self.details['mailid']
        self.domain = self.mail[self.mail.index('@') + 1:]
        self.localname = self.details['localname']
        try:
            self.get_config()
        except:
            self.get_connection()
            if self.connected == 0:
                #Show custom not connected to internet message
                print("not connected to internet")
            if self.connected == 0:
                while self.connected != 1:
                    self.get_connection()
                try:
                    self.get_config()
                except:
                    pass
                    #show gui message
                    print("file not found ")

        with open(os.path.join(self.instdir,'pindleconfig.json'), 'r') as f:
            self.changes = json.load(f)

        if self.changes['device1']['name'] == self.details['localname']:
            self.basedonkey = True
            self.tosave = self.changes['device2']['name']
          
            self.addwatch = self.changes["connections"].keys()
        else:
            self.basedonkey = False
            self.addwatch = self.changes["connections"].values()
            self.tosave = self.changes['device1']['name']

        return self.changes['connections']  

    def get_config(self):
        if self.domain != "gmail.com":
            self.api = onedrive.LoadSession()
            onedrive.download(self.api, "pindleconfig.json", os.path.join(self.instdir,"pindleconfig.json"),'file')
        else:
            self.api = googledrive.authenticate()
            googledrive.download(self.api, "pindleconfig.json", self.instdir, 'file')

    def upload(self,src):
        if self.domain != "gmail.com":
            onedrive.upload(self.api,'Pindle',src,'folder')
        else:
            googledrive.upload(self.api, src,"Pindle",  'file')
        self.save()

    def delete(self,src):
        if self.domain != "gmail.com":
            onedrive.delete(self.api,basename(src))
        else:
            googledrive.delete(self.api,basename(src),'file')
        self.save()

    def save(self):
        self.sync = {}
        self.sync['updates'] = self.updates
        self.sync['stack'] = self.stack
        with open('{}_changes.json'.format(self.tosave),'w+') as f:
            json.dump(self.sync,f)

        if self.domain != "gmail.com":
            onedrive.upload(self.api,'Pindle',"{}_changes.json".format(self.tosave),'folder')
        else:
            googledrive.upload(self.api, "{}_changes.json".format(self.tosave),"Pindle", 'file')

def on_create(src):
    if basename(src) in paths.stack:
        paths.stack.remove(basename(src))
    paths.stack.append(basename(src))
    if paths.basedonkey == True:
        location = paths.paths[dirname(src)]
    else:
        location = list(paths.paths.keys())[list(paths.paths.values()).index(dirname(src))]
    paths.updates[basename(src)] = (location, "created")
    print(paths.updates)
    print(paths.stack)
    print('uploading '+src)
    paths.upload(src)

def on_deleted(src):
    if basename(src) in paths.stack:
        paths.stack.remove(basename(src))
    paths.stack.append(basename(src))
    if paths.basedonkey == True:
        location = paths.paths[dirname(src)]
    else:
        location = list(paths.paths.keys())[list(paths.paths.values()).index(dirname(src))]
    paths.updates[basename(src)] = (location, "deleted")
    paths.delete(src)

class Event(LoggingEventHandler):
    @staticmethod
    def on_any_event(event, **kwargs):
        if event.is_directory:
            return None
        # Create a watchdog in Python to look for filesystem changes
        elif event.event_type == 'created' or event.event_type == "modified":
           try:
                print("created event")
                on_create(event.src_path)
           except:
                pass
        elif event.event_type == 'deleted':
            try:
                print("deleted")
                on_deleted(event.src_path)
            except:
                pass

if __name__ == "__main__":
    paths = Changes()
    event_handlers = Event()
    watcher = Observer()
    threads= []

    for i in paths.addwatch:
        targetPath = i
        print(i)
        watcher.schedule(event_handlers, targetPath, recursive=False)
        threads.append(watcher)

    watcher.start()
        #show network disconnected error
    watcher.join()
