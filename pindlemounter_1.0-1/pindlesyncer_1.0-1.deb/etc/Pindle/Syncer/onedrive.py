import onedrivesdk
from onedrivesdk.helpers import GetAuthCodeServer
from onedrivesdk.model import quota
import os

globals()['fid'] = None

def Authenticate():
    base_url = 'https://api.onedrive.com/v1.0/'
    redirect_uri = "http://localhost:8080/"
    client_secret = 'ews~S-~G8qr459UdX.juBHi6HoDdC~101m'
    scopes = ['wl.signin', 'wl.offline_access', 'onedrive.readwrite']
    client_id = 'cb1a2f6a-8c5d-43d9-ba34-3dab767fa0ac'
    client = onedrivesdk.get_default_client(client_id, scopes=scopes)
    auth_url = client.auth_provider.get_auth_url(redirect_uri)
    http = onedrivesdk.HttpProvider()
    code = GetAuthCodeServer.get_auth_code(auth_url, redirect_uri)
    auth_provider = onedrivesdk.AuthProvider(http_provider=http,
                                             client_id=client_id,
                                             scopes=scopes)
    auth_provider.authenticate(code, redirect_uri, client_secret)
    # Save the session for later
    os.chdir("/etc/Pindle/Syncer/")
    auth_provider.save_session()
    return client

def LoadSession():
    base_url = 'https://api.onedrive.com/v1.0/'
    http = onedrivesdk.HttpProvider()
    client_id = 'cb1a2f6a-8c5d-43d9-ba34-3dab767fa0ac'
    scopes = ['wl.signin', 'wl.offline_access', 'onedrive.readwrite']
    auth_provider = onedrivesdk.AuthProvider(http_provider=http,
                                             client_id=client_id,
                                             scopes=scopes)
    os.chdir("/etc/Pindle/Syncer/")
    auth_provider.load_session()
    auth_provider.refresh_token()
    client = onedrivesdk.OneDriveClient(base_url, auth_provider, http)
    return client

def download(api,filename,destination,type):
    search(api,"/",os.path.basename(filename),[],type)
    api.item(id = get_fid()).download(destination)

def upload(api,destination,source,type):
    search(api, "/", os.path.basename(destination), [], type)
    api.item(id= get_fid()).children[os.path.basename(source)].upload(source)

def search(api,path,sname,hier,type):
    try:
        items_iter = api.item(path=path).children.get()
    except:
        return
    hier.append(path)
    name = os.path.join(*hier)
    for item in items_iter:
        if item.folder is None:
            if sname == item.name and type == "file":
                globals()['fid'] = item.id
        else:
            if sname == item.name and type=="folder":
                globals()['fid'] = item.id
            search(api,item.name,sname, hier,type)
    hier.remove(path)

def create_folder(api,name,parent):
        item = onedrivesdk.Item()
        item.name = name
        item.folder = onedrivesdk.Folder()
        api.item(path=parent).children.add(item)

def delete(api,name):
    search(api,"root",name,[],'file')
    api.item(id=get_fid()).delete()

def get_fid():
    fid = globals()['fid']
    globals()['fid'] = None
    return fid