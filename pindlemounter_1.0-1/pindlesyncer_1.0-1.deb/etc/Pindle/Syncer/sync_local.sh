#!/usr/bin

python3 /etc/Pindle/Syncer/sync_download.py > /dev/null &