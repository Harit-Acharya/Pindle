import json
import os
import time, threading,shutil
import googledrive
import onedrive

WAIT_SECONDS = 600

def get_config(self,domain,instdir):
    if domain != "gmail.com":
        api = onedrive.LoadSession()
        onedrive.download(api, "pindleconfig.json",
                          os.path.join(instdir, "pindleconfig.json"), 'file')
    else:
        api = googledrive.authenticate()
        googledrive.download(api, "pindleconfig.json", instdir, 'file')
    return api

def sync():
    with open('/etc/Pindle/Syncer/localname.json') as f:
        details = json.load(f)
    mail = details['mailid']
    instdir = details['insdir']
    domain = mail[mail.index('@') + 1:]
    localname = details['localname']
    
    api = get_config(domain,instdir)
    with open('/etc/Pindle/Syncer/localname.json') as f:
        config = json.load(f)

    if config['device1']['name'] == details['localname']:
        config['device1']['size'] = shutil.disk_usage('/')
    else:
        config['device2']['size'] = shutil.disk_usage('/')

    with open(os.path.join(instdir,'pindleconfig.json'), 'w+') as f:
        json.dump(config, f)

    if domain != "gmail.com":
        googledrive.upload(api, os.path.join(instdir, 'pindleconfig.json'), "Pindle", 'file')
    else:
        onedrive.upload(api, "Pindle", os.path.join(instdir, 'pindleconfig.json'), 'folder')
    print("uploaded {}".format(time.ctime()))
    threading.Timer(WAIT_SECONDS, sync).start()

sync()