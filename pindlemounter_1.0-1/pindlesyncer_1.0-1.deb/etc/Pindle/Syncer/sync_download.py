from PyQt5.QtGui import QIcon,QMovie
from PyQt5.QtWidgets import QErrorMessage, QMainWindow, QListWidgetItem, QMessageBox
from PyQt5 import uic,QtCore
import onedrive
import os
import googledrive
import json,requests
import time
import sys
from PyQt5 import QtWidgets,uic,QtCore

class UI(QMainWindow):
    def __init__(self):
        super(UI,self).__init__()
        uic.loadUi("/etc/Pindle/Syncer/changes_made.ui", self)
        self.errorbox = QErrorMessage()
        self.setWindowTitle("Pindle Syncer Local Sync")
        self.setWindowIcon(QIcon("/usr/share/pixmaps/Pindle/Syncer/sync.png"))
        self.connected = 0
        self.url = "https://www.google.com"
        self.timeout = 3
        self.load_sessions()
        self.centerOnScreen()
        self.pushButton_3.clicked.connect(self.remove)
        self.pushButton_2.clicked.connect(self.load_changes)
        self.pushButton.clicked.connect(self.cancel)

    def cancel(self):
        self.msgBox = QMessageBox()
        self.msgBox.setIcon(QMessageBox.Information)
        self.msgBox.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        self.msgBox.setText("Do you really want to cancel")
        returnValue = self.msgBox.exec()
        if returnValue == QMessageBox.Ok:
            exit(0)

    def centerOnScreen(self):
        resolution = QtWidgets.QDesktopWidget().screenGeometry()
        self.move((resolution.width() // 2) - (self.frameSize().width() // 2),
                  (resolution.height() // 2) - (self.frameSize().height() // 2))

    def get_connection(self):
        try:
            request = requests.get(self.url, timeout=self.timeout)
            self.connected = 1
        except (requests.ConnectionError, requests.Timeout) as exception:
            self.connected = 0

    def load_sessions(self):
        try:
            with open('/etc/Pindle/Syncer/localname.json') as f:
                self.details = json.load(f)
        except:
            self.errorbox.showMessage("Localname.json file not found!!")
            time.sleep(10)
            exit(0)
        self.mail = self.details['mailid']
        self.instdir = self.details['insdir']
        self.domain = self.mail[self.mail.index('@') + 1:]
        self.localname = self.details['localname']
        try:
            self.get_config()
        except:
            self.get_connection()
            if self.connected == 0:
                self.errorbox.showMessage("Internet connection Lost!!!")
            if self.connected == 0:
                while self.connected != 1:
                    self.get_connection()
                try:
                    self.get_config()
                except:
                    self.errorbox.showMessage("{}_changes.json file not found".format(self.localname))
                    exit(0)

        with open('/etc/Pindle/Syncer/{}_changes.json'.format(self.localname), 'r') as f:
            self.changes = json.load(f)

        self.list_changes()

    def get_config(self):
        if self.domain != "gmail.com":
            self.api = onedrive.LoadSession()
            onedrive.download(self.api, "{}_changes.json".format(self.localname), os.path.join(self.instdir,"{}_changes.json".format(self.localname)),'file')
        else:
            self.api = googledrive.authenticate()
            googledrive.download(self.api, "{}_changes.json".format(self.localname), self.instdir, 'file')

    def remove(self,value):
        listItems = list(self.listWidget.selectedItems())
        if not listItems: return
        for item in listItems:
            index = self.listWidget.indexFromItem(item)
            self.listWidget.takeItem(index.row())
            name = item.text()
            name = name.split('..........')[0]
            del self.changes['updates'][name]
            self.changes["stack"].remove(name)

    def stopanimation(self):
        self.movie.stop()

    def trying(self):
        self.label_11.setGeometry(QtCore.QRect(260, 240, 400, 180))
        self.label_11.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.movie = QMovie('/usr/share/pixmaps/Pindle/Syncer/waited.gif')
        self.label_2.setMovie(self.movie)
        timer4 = QtCore.QTimer(self)
        self.movie.start()
        timer4.singleShot(20000, self.stopanimation)

    def list_changes(self):
        for filename,location in self.changes['updates'].items():
            item = QListWidgetItem("{}..........({})".format(filename,location[0]))
            self.listWidget.addItem(item)

    def load_changes(self):
        os.system("systemctl stop sync_remote")
        stack = self.changes['stack']
        self.trying()
        for unstack in stack:
            operations = self.changes['updates'][unstack]
            try:
                if operations[1] == "deleted":
                    os.system("sudo rm -f "+os.path.join(operations[0],unstack))
                    self.label_4.setText("Deleting {} from location {}".format(unstack,operations[0]))
                else:
                    self.label_4.setText("Downloading {} to location {}".format(unstack,operations[0]))
                    if self.domain != "gmail.com":
                        onedrive.download(self.api, "{}".format(unstack), os.path.join(operations[0],"{}".format(unstack)),'file')
                    else:
                        googledrive.download(self.api, "{}".format(unstack), operations[0], 'file')
            except:
                self.errorbox.showMessage("file not found or folder in not deleted in local device")
        self.stopanimation()
        self.errorbox.showMessage("Sync Completed")
        os.system("systemctl start sync_remote")
        exit(0)

if __name__ == "__main__":
    arr = QtWidgets.QApplication(sys.argv)
    run = UI()
    run.show()
    arr.exec_()