from random import randint
from PyQt5 import QtWidgets,uic
import sys,json
from firstwindow import firstwinshow
import onedrive_auth
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QPushButton, QLabel, QErrorMessage, QGroupBox
from Google import Create_Service
import time
import onedrive,googledrive

def getdetails(errorbox):
    try:
        with open('localname.json') as f:
            details = json.load(f)
            return details
    except:
        errorbox.showMessage("localname.json file not found")
        time.sleep(10)
        exit(0)


class secondwin(QtWidgets.QMainWindow):
    def __init__(self):
        super(secondwin,self).__init__()
        uic.loadUi('mainwindow.ui', self)
        self.error_dialog = QErrorMessage()
        self.details = getdetails()
        self.named = self.details["localname"]
        self.named2= self.details["device2"]
        self.mailid = self.details["mailid"]
        self.instdir = self.details["insdir"]
        self.check()
        self.gdrive = self.findChild(QPushButton,"pushButton")
        self.onedrive = self.findChild(QPushButton,"pushButton_2")
        self.logout = self.findChild(QPushButton,"pushButton_6")
        self.next = self.findChild(QPushButton,"pushButton_7")
        self.name = self.findChild(QPushButton,"pushButton_5")
        self.mail = self.findChild(QPushButton,"pushButton_4")
        self.name2 = self.findChild(QPushButton,"pushButton_9")
        self.setup = self.findChild(QPushButton,"pushButton_8")
        self.image = self.findChild(QLabel,"label")
        self.device2_storage = self.findChild(QLabel, "device2_storage")
        self.image.setPixmap(QPixmap(u"images/image{}.png".format(randint(1,9))))
        self.name2.setText(self.named2)
        self.name.setText(self.named)
        print(self.mailid)
        self.mail.setText(self.mailid)

    def loadsession(self):
        domain = self.mail[self.mail.index('@') + 1:]
        if domain != "gmail.com":
            try:
                api = onedrive.LoadSession()
                self.ctotal = api.drive.get().quota.total/(2**30)
                self.cused = api.drive.get().quota.used/(2**30)
                onedrive.download(api, "pindleconfig.json", self.instdir + "/pindleconfig.json", 'file')
            except:
                self.errorbox.showMessage("OOPS!! Something is Wrong!!\nPlease check your connection")
        else:
            try:
                CLIENT_SECRET_FILE = 'credentials.json'
                API_NAME = 'drive'
                API_VERSION = 'v3'
                SCOPES = ['https://www.googleapis.com/auth/drive']
                api = Create_Service(CLIENT_SECRET_FILE, API_NAME, API_VERSION, SCOPES)
                googledrive.download(api, "pindleconfig.json", self.instdir, 'file')
                response = api.about().get(fields='*').execute()
                i=0
                for k, v in response.get('storageQuota').items():
                    if i==0:
                        self.ctotal = v/(1024**3)
                    if i==1:
                        self.cused = v/(1024**3)
                    else:
                        break
            except:
                self.errorbox.showMessage("OOPS!! Something is Wrong!!\nPlease check your connection")

    def check(self):
        if self.details["firsttime"] == 0:
            self.details["firsttime"] = 1
            with open('localname.json', 'w') as json_file:
                json.dump(self.details, json_file)
            self.window = firstwinshow()
            self.hide()
            self.window.show()
        else:
            self.loadsession(self.mailid, self.error_dialog)
            with open(self.instdir+'pindleconfig.json', 'r') as f:
                self.config = json.load(f)
            self.device1_tsize = self.config['device1']['size'][0]/(1024**3)
            self.device1_tused = self.config['device1']['size'][1]/(1024**3)

            if self.config['issetup'] != 0:
                self.device2_tsize = self.config['device1']['size'][0]/(1024**3)
                self.device2_tused = self.config['device1']['size'][1]/(1024**3)
                ####here call all progressbars
            else:
                self.setEnabled(False)
                self.error_dialog.showMessage("someerror")
                self.device2_storage.setText("Unvailable")
                self.device2_perc.setText("0")
                #here call progressbar 1 and 2

    def next(self):
        pass

    def newsetup(self):
        pass

if __name__ == "__main__":
    arr=QtWidgets.QApplication(sys.argv)
    pi=secondwin()
    pi.show()
    arr.exec_()


